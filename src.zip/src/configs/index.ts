// export const BASE_URL = 'https://apidev.airsensa.io/api/V03/';
export const BASE_URL = 'https://foure.nodejsdapldevelopments.com/perpetuitycapital/public/api/v1/';