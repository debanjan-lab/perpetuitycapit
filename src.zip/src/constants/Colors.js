export default class Colors {
  static mainTextColor = '#000000';
  static subTextColor = '#C7C7C7';
  static greenColor = '#1A5632';
  static greenColorInactive = '#288f51';
  static whiteColor = '#FFFFFF';
  static greyColor = '#F2F2F3';
  static lightGreen = '#EEF9EF';
  static yellowColor = '#ffd700'
}
